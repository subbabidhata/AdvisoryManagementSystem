<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />

    <title> ADVISOR MANAGEMENT SYSTEM</title>
    <link rel="stylesheet" href="css/bootstrap.css"/>


</head>




<style>
    ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: black;
    }

    li {
        float: left;
        border-right:1px solid #bbb;
    }

    li:last-child {
        border-right: none;
    }

    li a {
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }

    li a:hover:not(.active) {
        background-color: green;
    }

    .active {
        background-color: none;
    }
</style>
<body>
<table class="table table-bordered">

    <tr bgcolor=#333 >
        <td align=center colspan="3">
            <font SIZE=6 color=white>ADVISOR MANAGEMENT SYSTEM</font>
        </td>
    </tr>

</table>





<ul>
    <li><a  href="myaccount.php">Home</a></li>

    <li style="float:right"><a href="logout.php">Logout</a></li>
</ul>



</body>
</html>